let handler = async m => m.reply(`

≡  *TheFlash-Bot-MD*

_GROUP:_
─────────────
▢ *Account Zack*
https://github.com/araab-zack
─────────────
▢ *YouTube*
• https://www.youtube.com/@V1_1Q
─────────────
▢ *YouTube*
• https://youtube.com/@user-jl2zt4nc6i?si=_nxA_D4KFhJU4ZZm
`.trim())
handler.help = ['gpflash']
handler.tags = ['main']
handler.command = ['group', 'support','الدعم','دعم']

export default handler
