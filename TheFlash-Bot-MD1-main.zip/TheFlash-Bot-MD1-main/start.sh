#!bin/bash
GREEN='\033[0;32m'
while :
do
echo ""
    npm start
    sleep 1

done 
